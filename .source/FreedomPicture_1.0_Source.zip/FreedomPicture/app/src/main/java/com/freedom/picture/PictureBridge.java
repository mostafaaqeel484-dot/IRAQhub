package com.freedom.picture;

import android.content.Context;
import android.os.Build;
import java.io.*;
import java.util.*;
import java.util.concurrent.TimeUnit;

/** Optional Amlogic sysfs bridge: reports only confirmed writes, never fakes success. */
public final class PictureBridge {
    private static final String[] NODES={
        "/sys/class/video/brightness", "/sys/class/video/contrast", "/sys/class/video/saturation"
    };
    private static final int[] MAX_DELTA={96,96,64};
    private final Context context;
    public PictureBridge(Context c){context=c.getApplicationContext();}
    public String detect(){
        StringBuilder sb=new StringBuilder();
        sb.append("Device: ").append(Build.MANUFACTURER).append(" / ").append(Build.MODEL)
          .append("\nBoard: ").append(Build.BOARD).append(" / ").append(Build.HARDWARE)
          .append("\nAndroid: ").append(Build.VERSION.RELEASE).append(" (API ").append(Build.VERSION.SDK_INT).append(")");
        for(String node:NODES){ File f=new File(node); sb.append("\n").append(node).append(": ");
            if(!f.exists())sb.append("missing");else sb.append(f.canRead()?"readable":"present").append(f.canWrite()?" / writable":" / protected"); }
        return sb.toString();
    }
    private String read(String path){
        try(BufferedReader br=new BufferedReader(new FileReader(path))){return br.readLine().trim();}
        catch(Exception e){return null;}
    }
    private boolean writeDirect(String path,String val){
        try(FileWriter out=new FileWriter(path)){out.write(val);out.flush();return true;}
        catch(Exception e){return false;}
    }
    private boolean writeRoot(String path,String val){
        // Paths and values come only from a fixed internal allowlist, never user supplied shell commands.
        try {
            Process p=new ProcessBuilder("su","-c","printf '%s' '"+val+"' > "+path).redirectErrorStream(true).start();
            if(!p.waitFor(2500,TimeUnit.MILLISECONDS)){p.destroyForcibly();return false;}
            return p.exitValue()==0;
        }catch(Exception e){return false;}
    }
    public String apply(int[] userValues,boolean allowRoot){
        if(userValues==null||userValues.length!=5)return "خطأ في القيم";
        int success=0,available=0;StringBuilder details=new StringBuilder();
        for(int i=0;i<3;i++){
            String path=NODES[i];File f=new File(path);
            if(!f.exists()){details.append("\n-").append(path).append(": غير موجود");continue;}
            available++;
            String old=read(path);
            if(old!=null && !context.getSharedPreferences("picture",0).contains("original_"+i)){
                context.getSharedPreferences("picture",0).edit().putString("original_"+i,old).apply();
            }
            int raw=Math.round((userValues[i]-50)*MAX_DELTA[i]/50f);
            String value=String.valueOf(raw);
            boolean write=writeDirect(path,value)||(allowRoot&&writeRoot(path,value));
            String seen=read(path);
            boolean confirmed=write&&seen!=null&&seen.equals(value);
            if(confirmed) success++;
            details.append("\n-").append(path).append(confirmed?": تم تأكيد كتابة "+seen:": تعذر تأكيد التغيير");
        }
        if(success==0)return "لم تُطبّق تعديلات العتاد. إعدادات الملف محفوظة فقط.\n"+details;
        return "تم تأكيد كتابة "+success+"/3 مسارات عتاد؛ اختبر الفرق بصرياً على قناة DVB.\nالحدة و Hue يحتاجان واجهة جهاز خاصة.\n"+details;
    }
    public String restore(boolean allowRoot){
        int restored=0;
        for(int i=0;i<3;i++){
            String old=context.getSharedPreferences("picture",0).getString("original_"+i,null);
            if(old==null||!old.matches("[-+]?([0-9]+|0x[0-9a-fA-F]+)"))continue;
            boolean write=writeDirect(NODES[i],old)||(allowRoot&&writeRoot(NODES[i],old));
            if(write&&old.equals(read(NODES[i])))restored++;
        }
        return "استرجاع إعدادات الجهاز الأصلية: "+restored+"/3 مسارات مؤكدة.";
    }
}
