package com.freedom.picture;

public final class Profile {
    public final String title, description;
    public final int[] values;
    public Profile(String title, String description, int brightness, int contrast, int saturation, int hue, int sharpness) {
        this.title = title; this.description = description;
        this.values = new int[] {brightness, contrast, saturation, hue, sharpness};
    }
    public static final Profile[] PRESETS = new Profile[] {
        new Profile("ORIGINAL", "الصورة الأصلية بدون تعديل", 50, 50, 50, 50, 50),
        new Profile("DEFAULT", "صورة متوازنة للقنوات والبرامج", 50, 55, 53, 50, 52),
        new Profile("SPORT DETAILS", "تفاصيل أوضح للمباريات والحركة", 50, 63, 61, 50, 68),
        new Profile("CINEMA SOFT", "ألوان سينمائية وتباين ناعم", 45, 58, 49, 50, 42),
        new Profile("EASY ON EYE", "إضاءة هادئة للمشاهدة الطويلة", 37, 47, 43, 50, 38),
        new Profile("AI CORE", "توازن ذكي ثابت من دون معالجة AI مدفوعة", 51, 59, 56, 50, 60)
    };
    private Profile() { title=""; description=""; values=new int[5]; }
}
