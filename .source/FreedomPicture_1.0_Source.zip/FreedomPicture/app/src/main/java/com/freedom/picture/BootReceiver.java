package com.freedom.picture;
import android.content.*;
import android.os.Build;
import android.provider.Settings;

public class BootReceiver extends BroadcastReceiver {
 public void onReceive(Context context,Intent intent){
  if(!Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction()))return;
  android.content.SharedPreferences prefs=context.getSharedPreferences("picture",0);
  if(!prefs.getBoolean("auto_overlay",false)||!Settings.canDrawOverlays(context))return;
  Intent s=new Intent(context,TintService.class);
  for(int i=0;i<5;i++)s.putExtra("v"+i,prefs.getInt("v"+i,50));
  try { if(Build.VERSION.SDK_INT>=26) context.startForegroundService(s);else context.startService(s); }
  catch(Exception ignored){}
 }
}
