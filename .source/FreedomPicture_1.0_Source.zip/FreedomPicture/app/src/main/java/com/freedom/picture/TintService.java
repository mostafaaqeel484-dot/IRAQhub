package com.freedom.picture;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.*;
import android.provider.Settings;
import android.view.*;

/** Optional comfort dimming; does NOT claim to alter video contrast/sharpness. */
public class TintService extends Service {
    private WindowManager wm;private View tint;
    public void onCreate(){super.onCreate();wm=(WindowManager)getSystemService(WINDOW_SERVICE);}
    public int onStartCommand(Intent intent,int flags,int startId){
        if(intent==null||!Settings.canDrawOverlays(this)){stopSelf();return START_NOT_STICKY;}
        if(intent.getBooleanExtra("stop",false)){removeTint();stopForeground(true);stopSelf();return START_NOT_STICKY;}
        int[] values={50,50,50,50,50};
        for(int i=0;i<5;i++)values[i]=intent.getIntExtra("v"+i,50);
        float strength=Math.max(0,(50-values[0])/300f);
        int base=Color.rgb(4,7,20);
        if(tint==null){
            tint=new View(this);tint.setFocusable(false);
            WindowManager.LayoutParams lp=new WindowManager.LayoutParams(-1,-1,
                Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_SYSTEM_ALERT,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
            try{wm.addView(tint,lp);}catch(Exception e){stopSelf();return START_NOT_STICKY;}
        }
        tint.setBackgroundColor(base);tint.setAlpha(Math.min(.16f,strength));
        String id="freedom_picture_overlay";
        NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        if(Build.VERSION.SDK_INT>=26)nm.createNotificationChannel(new NotificationChannel(id,"Freedom Picture overlay",NotificationManager.IMPORTANCE_LOW));
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,id):new Notification.Builder(this);
        b.setSmallIcon(android.R.drawable.ic_menu_gallery).setContentTitle("Freedom Picture").setContentText("Comfort dim overlay active").setOngoing(true);
        startForeground(72,b.build());return START_STICKY;
    }
    private void removeTint(){if(tint!=null){try{wm.removeView(tint);}catch(Exception ignored){}tint=null;}}
    public void onDestroy(){removeTint();super.onDestroy();}
    public IBinder onBind(Intent intent){return null;}
}
