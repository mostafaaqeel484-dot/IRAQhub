# Freedom Picture 1.0

A free, offline Android TV / set-top box picture-profile controller, written independently. No serial activation, payment, analytics or network request.

## Features

* Original, Default, Sport Details, Cinema Soft, Easy on Eye and AI Core static presets (the name AI Core is a preset, **not** a machine-learning model).
* Five independent manual controls: Brightness, Contrast, Saturation, Hue and Sharpness; presets and custom profiles saved locally.
* Amlogic device diagnostics with read/write confirmation before claiming hardware success.
* Opt-in sysfs hardware bridge for three parameters only (brightness, contrast, saturation). Root use is explicitly opt-in and off by default; unsupported targets fail visibly.
* Optional Android overlay for gentle dimming; this overlay cannot enhance underlying DVB video sharpness, contrast or saturation.
* Android TV Leanback launcher integration and remote D-pad-friendly focus controls.

**Hardware warning:** System-wide DVB picture control is firmware-dependent. Android does not expose a universal non-privileged API for these operations. A working video PQ driver / vendor SystemControl / suitable privileges may be needed. An acknowledged sysfs write does not guarantee visually changed pixels. The app cannot replicate proprietary BEN10 native service behavior without device testing. This is NOT a hacked/re-signed BEN10 APK; it contains original source code and no third-party native libraries/assets.

## Build

Use Android SDK 35, JDK 17 and Gradle 8.10.2:

```
gradle assembleDebug
```

APK: `app/build/outputs/apk/debug/app-debug.apk`. GitHub Actions workflow can build and upload the APK artifact.

## Test on receiver

Install with `adb install -r app-debug.apk`, launch `com.freedom.picture/.MainActivity`, check the hardware diagnostics. Enable `Allow root writes` only if rooted and you agree to write to Amlogic video sysfs. Adjust one setting at a time and compare video. Use `Restore` if the effect is incorrect.
