package com.freedom.picture;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Process;
import android.util.Log;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Locale;

/**
 * Freedom Picture 1.2: vendor API picture adapter. This deliberately DOES NOT write
 * sysfs, call su, issue arbitrary HIDL transactions, or bundle proprietary BEN10 code.
 *
 * On supported Amlogic ROMs, com.droidlogic.app.SystemControlManager is a system
 * framework client of the vendor systemcontrol HIDL / native PQ implementation.
 * We detect that client, require getter/setter with known signatures, and confirm
 * each change by reading back the getter. If it is not reachable as a normal app,
 * we report the actual failure instead of fabricating a successful picture change.
 */
public final class PictureBridge {
    private static final String TAG="FreedomPQ";
    private static final String[] LABELS={"Brightness", "Contrast", "Saturation", "Hue", "Sharpness"};
    private static final String[] VENDOR_CLASS={
        "com.droidlogic.app.SystemControlManager"
    };
    private static final String[][] SET_METHODS={
        {"setBrightness", "SetBrightness", "native_SetBrightness"},
        {"setContrast", "SetContrast", "native_SetContrast"},
        {"setSaturation", "SetSaturation", "native_SetSaturation"},
        {"setHue", "SetHue", "native_SetHue"},
        {"setSharpness", "SetSharpness", "native_SetSharpness"}
    };
    private static final String[][] GET_METHODS={
        {"getBrightness", "GetBrightness", "native_GetBrightness"},
        {"getContrast", "GetContrast", "native_GetContrast"},
        {"getSaturation", "GetSaturation", "native_GetSaturation"},
        {"getHue", "GetHue", "native_GetHue"},
        {"getSharpness", "GetSharpness", "native_GetSharpness"}
    };
    private final Context app;
    private final SharedPreferences prefs;

    public PictureBridge(Context c) {
        app=c.getApplicationContext();
        prefs=app.getSharedPreferences("picture",Context.MODE_PRIVATE);
    }

    private static class Endpoint {
        Object receiver;
        Method[] get=new Method[5];
        Method[] set=new Method[5];
        String error;
        String className;
    }

    private static String shortError(Throwable e) {
        if(e instanceof InvocationTargetException && ((InvocationTargetException)e).getTargetException()!=null)
            e=((InvocationTargetException)e).getTargetException();
        return e.getClass().getSimpleName()+": "+String.valueOf(e.getMessage());
    }

    private Method getMethod(Class<?> type,String[] candidates,boolean setter,int index) {
        Class<?>[] params;
        if(!setter)params=new Class<?>[0];
        else if(index==4)params=new Class<?>[]{int.class,int.class,int.class};
        else params=new Class<?>[]{int.class,int.class};
        for(String name:candidates) {
            try {
                // Public vendor wrapper preferred (no hidden/private API bypass).
                return type.getMethod(name,params);
            } catch(NoSuchMethodException ignored) {}
            try {
                // Some vendor ROMs ship only the private native entrypoint. Android
                // may block access here, which we explicitly expose as diagnostic.
                Method m=type.getDeclaredMethod(name,params);
                m.setAccessible(true);
                return m;
            } catch(Throwable ignored) {}
        }
        return null;
    }

    private Endpoint connect() {
        Endpoint e=new Endpoint();
        StringBuilder errors=new StringBuilder();
        for(String vendor:VENDOR_CLASS) {
            try {
                Class<?> clazz=Class.forName(vendor);
                Method instance=clazz.getMethod("getInstance");
                Object manager=instance.invoke(null);
                if(manager==null)throw new IllegalStateException("getInstance() returned null");
                e.receiver=manager;
                e.className=vendor;
                for(int i=0;i<5;i++) {
                    e.get[i]=getMethod(clazz,GET_METHODS[i],false,i);
                    e.set[i]=getMethod(clazz,SET_METHODS[i],true,i);
                }
                return e;
            } catch(Throwable ex) {
                errors.append(vendor).append(" -> ").append(shortError(ex)).append("\n");
            }
        }
        e.error=errors.length()==0?"No framework class available":errors.toString().trim();
        return e;
    }

    /** Obtain a current PQ getter result from the actual vendor manager. */
    private Integer read(Endpoint e,int index) throws Exception {
        if(e.get[index]==null)return null;
        Object result=e.get[index].invoke(e.receiver);
        if(!(result instanceof Number))return null;
        int n=((Number)result).intValue();
        // Amlogic getters normally expose 0..100. -1 is a HAL failure sentinel.
        return n>=0 && n<=100 ? n : null;
    }
    private Object write(Endpoint e,int index,int value) throws Exception {
        if(index==4)return e.set[index].invoke(e.receiver,value,1,0); // enable, do not persist
        return e.set[index].invoke(e.receiver,value,0); // don't persist vendor global defaults
    }
    private static String methodName(Method m) {return m==null?"not exposed":m.getName();}
    private static int clamp(int n,int a,int b){return Math.max(a,Math.min(b,n));}
    private static String resultString(Object r){return r==null?"void":String.valueOf(r);}

    /** Read-only discovery of known vendor HIDL service (no transact, no sysfs). */
    private String hidlDiscovery() {
        String[] descriptors={
            "vendor.amlogic.hardware.systemcontrol@1.1::ISystemControl",
            "vendor.amlogic.hardware.systemcontrol@1.0::ISystemControl"
        };
        StringBuilder output=new StringBuilder();
        try {
            Class<?> hw=Class.forName("android.os.HwBinder");
            Method getService;
            boolean triple=true;
            try{getService=hw.getDeclaredMethod("getService",String.class,String.class,boolean.class);}
            catch(NoSuchMethodException x){getService=hw.getDeclaredMethod("getService",String.class,String.class);triple=false;}
            getService.setAccessible(true);
            for(String descriptor:descriptors) {
                try{
                    Object binder=triple?getService.invoke(null,descriptor,"default",false):getService.invoke(null,descriptor,"default");
                    output.append("\n").append(descriptor).append(": ")
                          .append(binder==null?"not registered / inaccessible":"binder located (no calls sent)");
                } catch(Throwable e){output.append("\n").append(descriptor).append(": ").append(shortError(e));}
            }
        }catch(Throwable e) {
            output.append("\nHIDL service lookup: ").append(shortError(e));
        }
        return output.toString();
    }

    public String detect() {
        StringBuilder b=new StringBuilder("Freedom Picture 1.2 | VENDOR PQ / READ ONLY\n");
        b.append("Device: ").append(Build.MANUFACTURER).append(" / ").append(Build.MODEL)
         .append("\nChipset: ").append(Build.HARDWARE).append(" / ").append(Build.BOARD)
         .append("\nAndroid: ").append(Build.VERSION.RELEASE)
         .append(" | UID: ").append(Process.myUid())
         .append("\nSource transport: Amlogic SystemControlManager (no root, no sysfs writes).\n");
        Endpoint e=connect();
        if(e.receiver==null) {
            b.append("Vendor manager not reachable: ").append(e.error).append("\n");
        } else {
            b.append("Vendor manager: ").append(e.className).append("\n");
            for(int i=0;i<5;i++) {
                b.append(LABELS[i]).append(": read=").append(methodName(e.get[i]))
                 .append(" write=").append(methodName(e.set[i]));
                try{b.append(" current=").append(read(e,i));}
                catch(Throwable t){b.append(" error=").append(shortError(t));}
                b.append("\n");
            }
        }
        b.append(hidlDiscovery());
        b.append("\nNo license checks copied. No uncertain HIDL transaction IDs used.")
         .append("\nSuccessful read-back does not prove visible DVB change.");
        return b.toString();
    }

    /** Presets use relative offsets anchored to the actual vendor getter values. */
    public String apply(int[] requested,boolean unusedLegacyRoot) {
        if(requested==null||requested.length!=5)return "ملف صورة غير صالح";
        Endpoint ep=connect();
        if(ep.receiver==null)return "لم يتصل بمحرك Amlogic عبر النظام.\n"+ep.error+"\nلا تغيير على الصورة.";
        StringBuilder details=new StringBuilder("Transport: "+ep.className+"\n");
        int confirmed=0, rejected=0, unchanged=0;
        for(int i=0;i<5;i++) {
            String key="vendor_baseline_"+i;
            details.append("\n").append(LABELS[i]).append(": ");
            if(ep.get[i]==null || ep.set[i]==null) {
                details.append("vendor getter/setter unavailable — NOT sent");rejected++;continue;
            }
            try {
                Integer before=read(ep,i);
                if(before==null) {
                    details.append("untrusted getter value — NOT sent");rejected++;continue;
                }
                int baseline=prefs.getInt(key,-1);
                if(baseline<0 || baseline>100) {
                    baseline=before;
                    prefs.edit().putInt(key,baseline).commit();
                }
                int target=clamp(baseline+Math.round((clamp(requested[i],0,100)-50)*0.5f),0,100);
                details.append("before=").append(before).append(" baseline=").append(baseline)
                       .append(" target=").append(target).append(" ");
                if(before==target){details.append("already set");unchanged++;continue;}
                Object reply=write(ep,i,target);
                Integer after=read(ep,i);
                if(after!=null&&after==target){confirmed++;details.append("read-back confirmed");}
                else{rejected++;details.append("not confirmed (reply=").append(resultString(reply))
                    .append(", read-back=").append(after).append(")");}
            } catch(Throwable ex) {
                details.append("vendor access failed: ").append(shortError(ex));rejected++;
            }
        }
        Log.i(TAG,"PQ vendor apply confirmed="+confirmed+" rejected="+rejected);
        return "محرك Amlogic: "+confirmed+" تغييرات مؤكدة بالقراءة، "+unchanged+" بلا تغيير، "+rejected+" غير مؤكدة."
            +"\nلم يُفحص التأثير المرئي على DVB.\n"+details;
    }

    public String restore(boolean unusedLegacyRoot) {
        Endpoint ep=connect();
        if(ep.receiver==null)return "تعذّر الاتصال بخدمة Amlogic. لم يتم الاسترجاع: "+ep.error;
        int confirmed=0,failed=0;
        StringBuilder b=new StringBuilder("استرجاع القيم التي قرأها محرك Amlogic قبل أول تطبيق:\n");
        for(int i=0;i<5;i++) {
            int saved=prefs.getInt("vendor_baseline_"+i,-1);
            b.append(LABELS[i]).append(": ");
            if(saved<0||saved>100||ep.get[i]==null||ep.set[i]==null){b.append("no supported saved baseline\n");continue;}
            try {
                Integer current=read(ep,i);
                if(current==null){failed++;b.append("read failed\n");continue;}
                if(current==saved){confirmed++;b.append("already original\n");continue;}
                write(ep,i,saved);
                Integer after=read(ep,i);
                if(after!=null&&after==saved){confirmed++;b.append("restored\n");}
                else{failed++;b.append("not confirmed (read-back=").append(after).append(")\n");}
            }catch(Throwable ex){failed++;b.append(shortError(ex)).append("\n");}
        }
        return "Amlogic restore: "+confirmed+" read-back OK / "+failed+" failed.\n"+b;
    }
}
