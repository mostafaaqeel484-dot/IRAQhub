# Freedom Picture 1.2.0 — Amlogic vendor PQ

Independent, free Android TV picture profile application. This release **replaces**
the 1.0/1.1 raw sysfs path with a vendor framework transport, aligned with the
HIDL / JNI architecture observed in the reference BEN10 Picture Engine APK.

## Implementation
- Runtime checks for `com.droidlogic.app.SystemControlManager` and its `getInstance()`.
- Uses matching getter and setter signatures for brightness, contrast,
  saturation, hue and sharpness, *when that vendor class and those methods are
  actually accessible to this ordinary third-party Android application*.
- Uses vendor getter values to establish a baseline before any request;
  bounded ±25-point slider offsets; no writing when no trusted getter is present.
- Confirms each write by reading back via the SAME vendor getter. A readback is
  not evidence of visible DVB effect — visual testing on receiver is required.
- Read-only `HwBinder.getService` discovery for known Amlogic systemcontrol
  HIDL 1.0 and 1.1 descriptors. No arbitrary transaction IDs are issued.
- No `su`, ADB bridge, sysfs write, original app binary, signature substitution,
  licensing dependency, or activation bypass.

## Important compatibility limitations
- BEN10's binary uses HIDL (`HwBinder`/`HwParcel`), but its full HIDL transaction
  protocol, service identity and access policy remain unverified on this
  particular ROM; source-level compatibility is not equivalent to an empirically
  verified device-level implementation.
- Older Amlogic ROM vendor framework classes may be private or absent on S7D,
  and Android hidden API / vendor permission policy may deny third-party calls.
- If the app says `vendor getter/setter unavailable` or `not reachable`, no
  hardware picture adjustment has been verified. Do not claim success based
  on profile persistence, a successful build, or a UI change.
- When the firmware does not expose the vendor API, this APK retains the UI,
  profiles, and diagnostic reporting but cannot legitimately elevate privileges.

## Build
Android Gradle Plugin 9.5.0 / Gradle 9.8.2 / Java 17. `gradle assembleDebug`.
Application ID `com.freedom.picture`, version code 3.
