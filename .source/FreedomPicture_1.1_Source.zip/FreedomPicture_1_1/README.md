# Freedom Picture 1.1 — Amlogic S7D compatibility / permissions fix

Offline/free independent Android TV picture-control project. No license checks or third-party native code.

## Fixed after diagnostics from Amlogic s7d Android 14 (userdebug)
- The original firmware reads back `/sys/class/video/brightness=0`, `contrast=-128`, and `saturation=0`, with 0644 root ownership.
- The previous bridge incorrectly treated video contrast `0` as neutral. New code captures each receiver value as a baseline, then uses small bounded ±24 increments around that baseline. Treat ranges as **experimental** until proven on-device.
- If the app lacks permission, the new bridge **does not attempt protected writes** unless Expert/root is explicitly enabled. It differentiates protected paths, failed writes, no-change requests, and successful read-back.
- Restores captured original values rather than writing guessed zeros.
- Adds read-only discovery for `/sys/class/amvecm` PQ nodes, `/dev/amvecm`, `/dev/amvideo`, and aliases. **Does not write to unverified PQ controls.**
- Hue/sharpness remain profile-only; the hardware backend is not yet implemented for these sliders.
- Read-back confirmation does **not** guarantee that the live DVB frame is visually affected.

## Permissions
`/sys/class/video/*` on this device is root:root 0644, so a normal APK cannot modify it even with SELinux Permissive. ADB shell is uid 2000, also not root. `su` grant must actually exist for the Expert option to work. Enabling root checkbox alone never grants root.

A running `systemcontrol` process does not by itself grant public access to undocumented binder methods. `/dev/amvecm` requires additional permissions and vendor ioctl knowledge. This app does not bypass Android permissions.

## Build
Requires Android SDK 35, JDK 17, Gradle 9.8+ with AGP 9.5.0. Run `gradle assembleDebug` and install APK via `adb install -r`.

## Practical safe test
1. Open DEVICE DIAGNOSTICS and confirm protected paths.
2. If your device has an authorized `su` solution, opt in to Expert mode. Otherwise leave it off.
3. Keep DVB playing, adjust one supported control by a small increment, tap APPLY, inspect *both* read-back and the visible video. Do not claim picture enhancement solely from read-back.
4. Use RESTORE ORIGINAL to go back to captured values. Avoid repeated testing if the image becomes unstable.

**Caution:** Unverified PQ sysfs writes can make the picture wrong. This software intentionally does not touch undocumented amvecm or DRM/hardware nodes.
