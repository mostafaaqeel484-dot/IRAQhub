package com.freedom.picture;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Process;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.concurrent.TimeUnit;

/** Amlogic S7D-specific conservative sysfs transport.
 * Never treats a saved profile as a video picture change. This bridge can only modify
 * three vendor video values with real OS permission. Hue/sharpness remain unsupported.
 */
public final class PictureBridge {
    private static final String[] NODES={
        "/sys/class/video/brightness", "/sys/class/video/contrast", "/sys/class/video/saturation"
    };
    private static final String[] LABELS={"Brightness", "Contrast", "Saturation"};
    // Small bounded offsets relative to the receiver's read-back at first application.
    // Actual driver semantics/ranges are vendor-dependent; do not guess full range.
    private static final int[] DELTA={24,24,24};
    private static final String[] EXTRA={
        "/sys/class/video/vpp_brightness", "/sys/class/video/vpp_contrast",
        "/sys/class/amvecm/brightness", "/sys/class/amvecm/contrast",
        "/sys/class/amvecm/saturation_hue", "/sys/class/amvecm/cm2",
        "/dev/amvecm", "/dev/amvideo"
    };
    private final SharedPreferences prefs;
    public PictureBridge(Context c){prefs=c.getApplicationContext().getSharedPreferences("picture",Context.MODE_PRIVATE);}

    private String read(String path) {
        try(BufferedReader r=new BufferedReader(new FileReader(path))) {
            String s=r.readLine(); return s==null?null:s.trim();
        } catch(Exception e) { return null; }
    }
    private Integer parseDecimal(String s) {
        try { if(s==null || !s.matches("-?[0-9]{1,6}"))return null; return Integer.parseInt(s); }
        catch(Exception e){return null;}
    }
    private int clamp(int i,int min,int max){return Math.max(min,Math.min(max,i));}
    private String err(Exception e){return e.getClass().getSimpleName()+": "+String.valueOf(e.getMessage());}
    private String directWrite(String path,String val){
        try(FileWriter out=new FileWriter(path)) {out.write(val);out.flush();return "ok";}
        catch(Exception e){return err(e);}
    }
    private String rootWrite(String path,String val){
        // Path and value are from a fixed internal list and bounded decimal integers.
        ProcessBuilder b=new ProcessBuilder("su","-c","printf '%s' '"+val+"' > "+path);
        try{
            java.lang.Process p=b.redirectErrorStream(true).start();
            if(!p.waitFor(4,TimeUnit.SECONDS)){p.destroyForcibly();return "su timeout / rejected";}
            return p.exitValue()==0?"ok":"su returned "+p.exitValue()+" (grant root to this app if available)";
        } catch(Exception e){return err(e);}
    }
    public String detect(){
        StringBuilder sb=new StringBuilder();
        sb.append("Freedom Picture 1.1 | READ ONLY\n")
          .append("Device: ").append(Build.MANUFACTURER).append(" / ").append(Build.MODEL)
          .append("\nChipset: ").append(Build.HARDWARE).append(" / ").append(Build.BOARD)
          .append("\nAndroid: ").append(Build.VERSION.RELEASE).append(" | UID: ").append(Process.myUid())
          .append("\nNon-root Android apps cannot write root:root 0644 sysfs nodes.\n");
        for(int i=0;i<NODES.length;i++){
            File f=new File(NODES[i]);
            sb.append("\n").append(LABELS[i]).append(" ").append(NODES[i]).append(": ");
            if(!f.exists()) sb.append("MISSING");
            else sb.append(f.canRead()?"read":"no read").append(" / ")
                .append(f.canWrite()?"writable":"PROTECTED")
                .append(" / current=").append(read(NODES[i]));
        }
        sb.append("\n\nOTHER AMLOGIC NODES (discovery only; NO writes):");
        for(String path: EXTRA){
            File f=new File(path);sb.append("\n").append(path).append(": ")
                .append(f.exists()?(f.canRead()?"present/readable":"present/protected"):"missing");
        }
        sb.append("\n\n/dev/amvecm requires vendor ioctl/protocol and system permissions; support NOT implemented.");
        sb.append("\nHue and Sharpness: saved presets only. No native PQ vendor library bundled.");
        return sb.toString();
    }
    /** Apply sliders with a captured baseline and detailed reason codes. */
    public String apply(int[] requested,boolean allowRoot) {
        if(requested==null||requested.length!=5)return "خطأ: ملف الصورة غير صحيح";
        StringBuilder detail=new StringBuilder();int confirmed=0, unchanged=0;
        for(int i=0;i<3;i++){
            String path=NODES[i];File f=new File(path);
            detail.append("\n").append(LABELS[i]).append(" ");
            if(!f.exists()){detail.append("MISSING: ").append(path);continue;}
            Integer live=parseDecimal(read(path));
            if(live==null){detail.append("READ ERROR / unknown driver value");continue;}
            String key="original_"+i;
            Integer base=parseDecimal(prefs.getString(key,null));
            if(base==null) {
                base=live;
                // Store the true receiver baseline before any attempted write.
                prefs.edit().putString(key,String.valueOf(live)).commit();
            }
            int slider=clamp(requested[i],0,100);
            int offset=Math.round((slider-50)*DELTA[i]/50f);
            int target=clamp(base+offset,-128,127);
            detail.append("baseline=").append(base).append(", target=").append(target)
                  .append(", before=").append(live).append(" -> ");
            if(live==target){detail.append("UNCHANGED (no write needed)");unchanged++;continue;}
            if(!f.canWrite()&&!allowRoot){
                detail.append("BLOCKED: root:root 0644 / enable Expert only if su is installed");continue;
            }
            String result=f.canWrite()?directWrite(path,String.valueOf(target)):rootWrite(path,String.valueOf(target));
            String after=read(path);
            if(!"ok".equals(result))detail.append("WRITE FAILED: ").append(result);
            else if(!String.valueOf(target).equals(after))detail.append("NOT CONFIRMED: read-back=").append(after);
            else {detail.append("WRITE CONFIRMED: ").append(after).append(" (visual impact unverified)");confirmed++;}
        }
        detail.append("\nHue/Sharpness: NO compatible control protocol confirmed; NOT applied.");
        if(confirmed==0)
            return "لم يتأكد أي تعديل جديد على DVB. المسارات محمية أو لم تتغير.\n"+detail;
        return "تمت كتابة "+confirmed+" مسارات وتأكيدها؛ افحص اختلاف الصورة على DVB بنفسك.\n"+detail;
    }
    public String restore(boolean allowRoot){
        int restored=0, unchanged=0;StringBuilder details=new StringBuilder();
        for(int i=0;i<3;i++){
            String path=NODES[i];Integer orig=parseDecimal(prefs.getString("original_"+i,null));
            if(orig==null){details.append("\n").append(LABELS[i]).append(": no baseline saved");continue;}
            File f=new File(path);
            if(!f.exists()){details.append("\n").append(LABELS[i]).append(": missing");continue;}
            Integer current=parseDecimal(read(path));
            if(current!=null&&current.equals(orig)){
                unchanged++;details.append("\n").append(LABELS[i]).append(": already original ").append(orig);continue;
            }
            if(!f.canWrite()&&!allowRoot){details.append("\n").append(LABELS[i]).append(": protected; not restored");continue;}
            String result=f.canWrite()?directWrite(path,String.valueOf(orig)):rootWrite(path,String.valueOf(orig));
            Integer after=parseDecimal(read(path));
            if("ok".equals(result)&&orig.equals(after)){
                restored++;details.append("\n").append(LABELS[i]).append(": restored ").append(orig);
            }else details.append("\n").append(LABELS[i]).append(": restore FAILED ").append(result).append(" / readback=").append(after);
        }
        return "استرجاع القيم الأصلية: "+restored+" مؤكد، "+unchanged+" لم يحتج تغيير.\n"+details;
    }
}
