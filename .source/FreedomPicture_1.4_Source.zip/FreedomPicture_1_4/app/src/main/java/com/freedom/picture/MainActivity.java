package com.freedom.picture;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.util.*;

public final class MainActivity extends Activity {
    private static final int BG=Color.rgb(7,12,25), PANEL=Color.rgb(18,29,49),
        WHITE=0xfff4f8ff, SUB=0xff9baec7, CYAN=0xff1ed9f5, PURPLE=0xff936bff;
    private static final String[] NAMES={"Brightness / السطوع","Contrast / التباين", "Saturation / التشبع", "Hue / درجة اللون", "Sharpness / الحدة"};
    private final int[] values={50,50,50,50,50};
    private final SeekBar[] sliders=new SeekBar[5];
    private final TextView[] nums=new TextView[5];
    private final ArrayList<Button> presetButtons=new ArrayList<>();
    private TextView status,titleMode,desc,bridgeStatus;
    private CheckBox autoOverlay;
    private android.content.SharedPreferences prefs;
    private int selected=0;
    private PictureBridge bridge;

    @Override public void onCreate(Bundle state){super.onCreate(state);
        getWindow().setFlags(1024,1024);getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
        prefs=getSharedPreferences("picture",MODE_PRIVATE);bridge=new PictureBridge(this);
        for(int i=0;i<5;i++)values[i]=prefs.getInt("v"+i,50);
        selected=prefs.getInt("selected",0);
        buildUi();
    }
    private GradientDrawable bg(int color,int line,int r){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(r));
        if(line!=0)d.setStroke(dp(1),line);return d;}
    private GradientDrawable gradient(){GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.TL_BR,
        new int[]{0xff102f59,0xff221843,0xff0d1d37});d.setCornerRadius(dp(16));d.setStroke(dp(1),0xff38547f);return d;}
    private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
    private TextView text(String s,int sp,int c,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(sp);t.setTextColor(c);
        if(bold)t.setTypeface(android.graphics.Typeface.DEFAULT,1);t.setGravity(Gravity.CENTER_VERTICAL);return t;}
    private LinearLayout linear(boolean vertical){LinearLayout l=new LinearLayout(this);l.setOrientation(vertical?1:0);return l;}
    private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w<0?w:dp(w),h<0?h:dp(h));}
    private void space(LinearLayout l,int h){View v=new View(this);l.addView(v,lp(1,h));}
    private Button button(String s){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextSize(12);b.setTextColor(WHITE);
        b.setGravity(Gravity.CENTER);b.setBackground(bg(0xff233958,0xff40658a,10));b.setMinHeight(0);b.setMinimumHeight(0);
        b.setPadding(dp(6),dp(5),dp(6),dp(5));b.setFocusable(true);return b;}
    private LinearLayout panel(int pad){LinearLayout l=linear(true);l.setPadding(dp(pad),dp(pad),dp(pad),dp(pad));l.setBackground(bg(PANEL,0xff243b5d,14));return l;}
    private void buildUi(){
        LinearLayout root=linear(true);root.setBackgroundColor(BG);root.setPadding(dp(17),dp(12),dp(17),dp(10));
        setContentView(root);
        LinearLayout header=linear(false);header.setGravity(Gravity.CENTER_VERTICAL);
        TextView logo=text("◈",37,CYAN,true);header.addView(logo,lp(44,48));
        LinearLayout brand=linear(true);brand.addView(text("FREEDOM PICTURE",27,WHITE,true));
        brand.addView(text("FREE PICTURE ENGINE  •  Amlogic native vendor PQ",10,SUB,false));
        header.addView(brand,new LinearLayout.LayoutParams(0,dp(53),1));
        TextView offline=text("●  OFFLINE • FREE • NO LICENSE",12,0xff4ee8b7,true);
        offline.setGravity(Gravity.CENTER);offline.setBackground(bg(0xff103333,0xff206957,30));offline.setPadding(dp(15),0,dp(15),0);
        header.addView(offline,lp(255,38));root.addView(header,lp(-1,56));space(root,10);

        LinearLayout body=linear(false);body.setBaselineAligned(false);
        LinearLayout left=panel(12); LinearLayout.LayoutParams lpl=new LinearLayout.LayoutParams(0,-1,1.05f);lpl.rightMargin=dp(10);body.addView(left,lpl);
        left.addView(text("PICTURE MODES  |  أوضاع الصورة",14,WHITE,true));space(left,9);
        for(int i=0;i<Profile.PRESETS.length;i++){
            final int position=i;Profile p=Profile.PRESETS[i];Button b=button(p.title);
            b.setGravity(Gravity.CENTER_VERTICAL|Gravity.LEFT);b.setPadding(dp(13),0,0,0);
            LinearLayout.LayoutParams bp=lp(-1,43);bp.bottomMargin=dp(7);left.addView(b,bp);
            b.setOnClickListener(v->choosePreset(position));presetButtons.add(b);
        }
        Button openSaved=button("MY PROFILES   /   ملفاتي المحفوظة");openSaved.setOnClickListener(v->showProfiles());left.addView(openSaved,lp(-1,42));
        space(left,8);TextView device=text("CHIPSET: "+Build.HARDWARE+"   •   "+Build.MODEL,10,SUB,false);left.addView(device);

        LinearLayout middle=panel(15);LinearLayout.LayoutParams lpm=new LinearLayout.LayoutParams(0,-1,1.50f);lpm.rightMargin=dp(10);body.addView(middle,lpm);
        LinearLayout modeBanner=linear(true);modeBanner.setPadding(dp(13),dp(9),dp(13),dp(9));modeBanner.setBackground(gradient());
        modeBanner.addView(text("CURRENT PROFILE",10,CYAN,true));
        titleMode=text("ORIGINAL",19,WHITE,true);modeBanner.addView(titleMode);
        desc=text("",11,SUB,false);modeBanner.addView(desc);middle.addView(modeBanner,lp(-1,90));space(middle,10);
        middle.addView(text("CUSTOM COLOR CONTROL",14,WHITE,true));space(middle,3);
        for(int i=0;i<5;i++){
            final int index=i;
            LinearLayout line=linear(false);line.setGravity(Gravity.CENTER_VERTICAL);
            TextView label=text(NAMES[i],11,WHITE,false);line.addView(label,new LinearLayout.LayoutParams(0,dp(20),1));
            TextView counter=text(values[i]+"",12,CYAN,true);counter.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
            line.addView(counter,lp(35,20));nums[i]=counter;middle.addView(line,lp(-1,21));
            SeekBar bar=new SeekBar(this);bar.setMax(100);bar.setProgress(values[i]);bar.setProgressTintList(android.content.res.ColorStateList.valueOf(CYAN));
            bar.setThumbTintList(android.content.res.ColorStateList.valueOf(PURPLE));bar.setFocusable(true);
            bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
                public void onProgressChanged(SeekBar s,int progress,boolean user){values[index]=progress;nums[index].setText(progress+"");if(user)titleMode.setText("CUSTOM COLOR");}
                public void onStartTrackingTouch(SeekBar s){}
                public void onStopTrackingTouch(SeekBar s){}
            });
            sliders[i]=bar;middle.addView(bar,lp(-1,32));
        }
        LinearLayout controlRow=linear(false);
        Button save=button("SAVE CUSTOM  /  حفظ");save.setOnClickListener(v->saveProfile());controlRow.addView(save,new LinearLayout.LayoutParams(0,dp(38),1));
        TextView gap=text("  ",10,WHITE,false);controlRow.addView(gap);
        Button zero=button("RESET SLIDERS");zero.setOnClickListener(v->setValues(new int[]{50,50,50,50,50}));
        controlRow.addView(zero,new LinearLayout.LayoutParams(0,dp(38),1));middle.addView(controlRow);

        LinearLayout right=panel(12);body.addView(right,new LinearLayout.LayoutParams(0,-1,1.03f));
        right.addView(text("PICTURE ENGINE  /  التحكم",14,WHITE,true));space(right,9);
        Button apply=button("◉  APPLY PICTURE   /   تطبيق");apply.setTextColor(0xff09131f);apply.setTextSize(13);apply.setBackground(bg(CYAN,0,10));
        right.addView(apply,lp(-1,46));apply.setOnClickListener(v->applyHardware());space(right,8);
        Button original=button("↺  RESTORE ORIGINAL");right.addView(original,lp(-1,42));original.setOnClickListener(v->restore());space(right,8);
        Button overlay=button("◐  OVERLAY COMFORT  ON / OFF");right.addView(overlay,lp(-1,43));overlay.setOnClickListener(v->toggleOverlay());space(right,7);
        autoOverlay=new CheckBox(this);autoOverlay.setText("استعادة التعتيم بعد إعادة التشغيل");autoOverlay.setTextColor(SUB);autoOverlay.setTextSize(11);autoOverlay.setChecked(prefs.getBoolean("auto_overlay",false));
        autoOverlay.setOnCheckedChangeListener((v,on)->prefs.edit().putBoolean("auto_overlay",on).apply());right.addView(autoOverlay);
        TextView vendorInfo=text("◈  Amlogic Vendor API — بدون root",11,0xff64dec8,true);
        right.addView(vendorInfo,lp(-1,28));
        Button diagnose=button("▤  DEVICE DIAGNOSTICS");right.addView(diagnose,lp(-1,40));diagnose.setOnClickListener(v->showDiagnostics());space(right,8);
        Button adbLocal=button("◎  ADB CONNECT 127.0.0.1:5556");
        right.addView(adbLocal,lp(-1,40));adbLocal.setOnClickListener(v->connectLocalAdb(adbLocal));space(right,7);
        Button adbCheck=button("⌘  ADB PERMISSION CHECK  /  فحص صلاحيات ADB");
        right.addView(adbCheck,lp(-1,40));adbCheck.setOnClickListener(v->showAdbPermissions());space(right,8);
        bridgeStatus=text("Amlogic vendor control: يستخدم نفس فئة SystemControlManager إن وفّرها النظام، ولا يكتب إلى sysfs.",10,SUB,false);
        right.addView(bridgeStatus,lp(-1,-2));

        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.addView(body);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        space(root,8);
        status=text("v1.4 LOCAL ADB • NO AUTOMATIC PQ WRITES • NOT ROOT",12,0xffa9c3df,false);
        status.setPadding(dp(15),0,dp(15),0);status.setBackground(bg(0xff101f36,0xff264263,9));root.addView(status,lp(-1,45));
        if(selected>=0&&selected<Profile.PRESETS.length){Profile p=Profile.PRESETS[selected];titleMode.setText(p.title);desc.setText(p.description);}
        else{titleMode.setText("CUSTOM COLOR");desc.setText("التعديل اليدوي محفوظ على الجهاز");}
        highlight();
    }
    private void highlight(){for(int i=0;i<presetButtons.size();i++)presetButtons.get(i).setBackground(
        bg(i==selected?0xff254e68:0xff233958,i==selected?CYAN:0xff40658a,10));}
    private void choosePreset(int i){selected=i;Profile p=Profile.PRESETS[i];titleMode.setText(p.title);desc.setText(p.description);
        setValues(p.values);highlight();status.setText("تم اختيار "+p.title+". تطبيق العتاد يتطلب توفر واجهة PQ من النظام.");}
    private void setValues(int[] next){for(int i=0;i<5;i++){values[i]=Math.max(0,Math.min(100,next[i]));sliders[i].setProgress(values[i]);nums[i].setText(values[i]+"");}}
    private void persist(){android.content.SharedPreferences.Editor e=prefs.edit().putInt("selected",selected);
        for(int i=0;i<5;i++)e.putInt("v"+i,values[i]);e.apply();}
    private void applyHardware(){persist();status.setText("جارٍ الاتصال بمحرك Amlogic والتحقق من القيم... ");
        final int[] snapshot=values.clone();final boolean root=false;
        new Thread(()->{String output=bridge.apply(snapshot,root);runOnUiThread(()->{
            status.setText(output.split("\\n")[0]);bridgeStatus.setText(output);});}).start();}
    private void restore(){prefs.edit().putBoolean("auto_overlay",false).apply();autoOverlay.setChecked(false);
        stopService(new Intent(this,TintService.class));setValues(Profile.PRESETS[0].values);
        selected=0;titleMode.setText("ORIGINAL");desc.setText(Profile.PRESETS[0].description);highlight();persist();
        status.setText("جارٍ استعادة القيم الأصلية عبر خدمة Amlogic...");
        boolean root=false;new Thread(()->{
            String result=bridge.restore(root);runOnUiThread(()->{status.setText(result);bridgeStatus.setText(result);});
        }).start();}
    private void toggleOverlay(){
        if(!Settings.canDrawOverlays(this)){
            new AlertDialog.Builder(this).setTitle("صلاحية الطبقة العائمة")
                .setMessage("هذه الطبقة للتعتيم الخفيف فقط وليست محركاً لتحسين الحدة والتباين. امنح الصلاحية ثم اضغط الزر مرة أخرى.")
                .setPositiveButton("إعدادات الصلاحية",(d,w)->{
                    Intent i=new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName()));
                    try{startActivity(i);}catch(Exception e){status.setText("تعذر فتح إعدادات الطبقة العائمة");}
                }).setNegativeButton("إلغاء",null).show();return;
        }
        boolean enabled=prefs.getBoolean("overlay_on",false);Intent intent=new Intent(this,TintService.class);
        if(enabled){stopService(intent);prefs.edit().putBoolean("overlay_on",false).apply();status.setText("OVERLAY OFF");}
        else{persist();for(int i=0;i<5;i++)intent.putExtra("v"+i,values[i]);
            try{if(Build.VERSION.SDK_INT>=26)startForegroundService(intent);else startService(intent);
                prefs.edit().putBoolean("overlay_on",true).apply();status.setText("OVERLAY ON: تعتيم خفيف فقط؛ لا يعدّل حدة الفيديو ولا ألوان DVB.");
            }catch(Exception e){status.setText("فشل تشغيل الطبقة: "+e.getMessage());}}
    }
    private void showDiagnostics(){String d=bridge.detect()+"\n\n"+AdbGrantProbe.report(this)+"\nLocal ADB test is available separately. No automatic root or PQ writes."+
        "\nNo external server • Offline • Package "+getPackageName();
        new AlertDialog.Builder(this).setTitle("Freedom Picture • Device Probe").setMessage(d)
            .setPositiveButton("إغلاق",null).setNeutralButton("نسخ",(a,b)->{
                ((android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("Freedom Picture probe",d));
                Toast.makeText(this,"تم نسخ التقرير",Toast.LENGTH_SHORT).show();}).show();}
    private void showAdbPermissions(){
        final String report=AdbGrantProbe.report(this);
        new AlertDialog.Builder(this).setTitle("Freedom Picture • ADB Permission Check")
            .setMessage(report).setPositiveButton("إغلاق",null)
            .setNeutralButton("نسخ التقرير",(d,w)->{
                ((android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE))
                    .setPrimaryClip(ClipData.newPlainText("Freedom Picture ADB permissions",report));
                Toast.makeText(this,"تم نسخ التقرير",Toast.LENGTH_SHORT).show();
            }).show();
    }
    private void connectLocalAdb(Button button){
        button.setEnabled(false);
        status.setText("ADB 127.0.0.1:5556 — جارٍ الاتصال والمصادقة... قد تظهر رسالة سماح ADB على الرسيفر");
        new Thread(()->{
            final String report=LocalAdbClient.connectAndCheck(this);
            runOnUiThread(()->{
                button.setEnabled(true);
                status.setText(report.startsWith("AUTHORIZED") ? "Local ADB authorized • shell identity checked" : "Local ADB: see connection report");
                new AlertDialog.Builder(this).setTitle("Freedom Picture • ADB 127.0.0.1:5556")
                    .setMessage(report).setPositiveButton("إغلاق",null)
                    .setNeutralButton("نسخ التقرير",(d,w)->{
                        ((android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE))
                            .setPrimaryClip(ClipData.newPlainText("Freedom Picture Local ADB",report));
                        Toast.makeText(this,"تم نسخ التقرير",Toast.LENGTH_SHORT).show();
                    }).show();
            });
        },"local-adb-check").start();
    }
    private void saveProfile(){EditText input=new EditText(this);input.setSingleLine(true);input.setText("My picture");input.setPadding(dp(20),dp(16),dp(20),dp(16));
        new AlertDialog.Builder(this).setTitle("حفظ إعدادات الصورة").setView(input)
            .setPositiveButton("SAVE",(d,w)->{
                String name=input.getText().toString().trim().replace("|"," ").replace(";"," ");
                if(name.length()<1)return;String key="custom_"+name;StringBuilder vals=new StringBuilder();
                for(int i=0;i<5;i++){if(i>0)vals.append(",");vals.append(values[i]);}
                String existing=prefs.getString("custom_names","");
                if(!Arrays.asList(existing.split("\\|",-1)).contains(name))existing+= (existing.isEmpty()?"":"|")+name;
                prefs.edit().putString(key,vals.toString()).putString("custom_names",existing).apply();
                status.setText("SAVED: "+name);}).setNegativeButton("إلغاء",null).show();}
    private void showProfiles(){String names=prefs.getString("custom_names","");
        if(names.isEmpty()){new AlertDialog.Builder(this).setMessage("ماكو ملفات محفوظة بعد. عدّل الألوان ثم اضغط SAVE CUSTOM.")
            .setPositiveButton("حسناً",null).show();return;}
        String[] list=names.split("\\|");
        new AlertDialog.Builder(this).setTitle("MY PROFILES").setItems(list,(d,which)->{
            String item=prefs.getString("custom_"+list[which],"");String[] parts=item.split(",");if(parts.length!=5)return;
            try{int[] next=new int[5];for(int i=0;i<5;i++)next[i]=Integer.parseInt(parts[i]);
                selected=-1;setValues(next);titleMode.setText(list[which]);desc.setText("Saved custom profile");highlight();
                status.setText("تم تحميل "+list[which]+". اضغط APPLY للتجربة.");}
            catch(NumberFormatException ignored){} }).setNegativeButton("إلغاء",null).show();}
    @Override protected void onPause(){super.onPause();persist();}
}
