package com.freedom.picture;

import android.content.Context;
import android.os.SystemClock;
import android.util.Base64;

import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.math.BigInteger;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Arrays;
import javax.crypto.Cipher;

/** Minimal ADB TCP client for the receiver's own loopback adbd.
 *  Does not invoke external binaries, use hidden APIs, request root or change PQ settings.
 *  The only remote shell command used is the read-only 'id' for proof of authorization.
 */
public final class LocalAdbClient {
    private static final String HOST="127.0.0.1";
    private static final int PORT=5556;
    private static final int CNXN=0x4e584e43, AUTH=0x48545541, OPEN=0x4e45504f,
        OKAY=0x59414b4f, WRTE=0x45545257, CLSE=0x45534c43;
    private static final int AUTH_TOKEN=1, AUTH_SIGNATURE=2, AUTH_RSAPUBLICKEY=3;
    private static final int MAX_PACKET=1024*1024;
    private static final String KEY_FILE="local_adb_rsa_v1.key";
    private static final byte[] SHA1_DIGEST_INFO={0x30,0x21,0x30,0x09,0x06,0x05,
        0x2b,0x0e,0x03,0x02,0x1a,0x05,0x00,0x04,0x14};

    private LocalAdbClient(){}

    private static class Packet {
        int command,arg0,arg1;
        byte[] data;
        Packet(int c,int a0,int a1,byte[] d){command=c;arg0=a0;arg1=a1;data=d;}
    }
    private static int checksum(byte[] d){int s=0;for(byte b:d)s+=(b&255);return s;}
    private static int getInt(byte[] d,int offset){return ByteBuffer.wrap(d,offset,4).order(ByteOrder.LITTLE_ENDIAN).getInt();}
    private static void putInt(byte[] d,int offset,int v){ByteBuffer.wrap(d,offset,4).order(ByteOrder.LITTLE_ENDIAN).putInt(v);}
    private static byte[] nul(String text){return (text+"\0").getBytes(StandardCharsets.UTF_8);}
    private static void send(OutputStream out,int command,int a0,int a1,byte[] payload)throws Exception{
        if(payload==null)payload=new byte[0];
        byte[] head=new byte[24];putInt(head,0,command);putInt(head,4,a0);putInt(head,8,a1);
        putInt(head,12,payload.length);putInt(head,16,checksum(payload));putInt(head,20,command^-1);
        out.write(head);out.write(payload);out.flush();
    }
    private static Packet receive(InputStream in)throws Exception{
        byte[] header=new byte[24];new DataInputStream(in).readFully(header);
        int command=getInt(header,0),length=getInt(header,12);
        if((command^getInt(header,20))!=-1 || length<0 || length>MAX_PACKET)
            throw new java.io.IOException("Invalid ADB packet header / length: "+length);
        byte[] payload=new byte[length];new DataInputStream(in).readFully(payload);
        int recorded=getInt(header,16);
        if(recorded!=0 && recorded!=checksum(payload))throw new java.io.IOException("ADB packet checksum error");
        return new Packet(command,getInt(header,4),getInt(header,8),payload);
    }
    private static byte[] fileRead(File f)throws Exception{
        try(FileInputStream in=new FileInputStream(f)){
            ByteArrayOutputStream b=new ByteArrayOutputStream();byte[] tmp=new byte[1024];int n;
            while((n=in.read(tmp))!=-1)b.write(tmp,0,n);
            return b.toByteArray();
        }
    }
    /** Key kept exclusively in app-private no-backup storage, not exported to network. */
    private static KeyPair keyPair(Context ctx)throws Exception{
        File file=new File(ctx.getNoBackupFilesDir(),KEY_FILE);
        KeyFactory factory=KeyFactory.getInstance("RSA");
        if(file.isFile()){
            byte[] bytes=fileRead(file);
            if(bytes.length<16 || bytes.length>10000)throw new java.io.IOException("Invalid local ADB key");
            int privateLen=getInt(bytes,0),publicLen=getInt(bytes,4);
            if(privateLen<=0||publicLen<=0||privateLen+publicLen!=bytes.length-8)
                throw new java.io.IOException("Invalid saved ADB key format");
            PrivateKey privateKey=factory.generatePrivate(new PKCS8EncodedKeySpec(Arrays.copyOfRange(bytes,8,8+privateLen)));
            PublicKey publicKey=factory.generatePublic(new X509EncodedKeySpec(Arrays.copyOfRange(bytes,8+privateLen,bytes.length)));
            return new KeyPair(publicKey,privateKey);
        }
        KeyPairGenerator g=KeyPairGenerator.getInstance("RSA");g.initialize(2048);
        KeyPair pair=g.generateKeyPair();byte[] priv=pair.getPrivate().getEncoded(),pub=pair.getPublic().getEncoded();
        byte[] all=new byte[8+priv.length+pub.length];putInt(all,0,priv.length);putInt(all,4,pub.length);
        System.arraycopy(priv,0,all,8,priv.length);System.arraycopy(pub,0,all,8+priv.length,pub.length);
        try(FileOutputStream out=new FileOutputStream(file)){out.write(all);out.getFD().sync();}
        return pair;
    }
    private static void putLittleNumber(byte[] dest,int start,int length,BigInteger v){
        byte[] big=v.toByteArray();for(int i=0;i<length;i++)dest[start+i]=i<big.length?big[big.length-i-1]:0;
    }
    /** ADB accepts a base64 524-byte RSAPublicKey struct, not X.509 PEM. */
    private static byte[] adbPublicKey(RSAPublicKey rsa){
        final int words=64,modulusLength=256;
        BigInteger n=rsa.getModulus(), two32=BigInteger.ONE.shiftLeft(32);
        if(n.bitLength()!=2048)throw new IllegalArgumentException("ADB requires 2048-bit RSA");
        BigInteger n0=n.and(two32.subtract(BigInteger.ONE));
        long n0inv=two32.subtract(n0.modInverse(two32)).longValue() & 0xffffffffL;
        BigInteger rr=BigInteger.ONE.shiftLeft(modulusLength*16).mod(n);
        byte[] buf=new byte[4+4+modulusLength+modulusLength+4];
        putInt(buf,0,words);putInt(buf,4,(int)n0inv);
        putLittleNumber(buf,8,modulusLength,n);
        putLittleNumber(buf,8+modulusLength,modulusLength,rr);
        putInt(buf,8+modulusLength*2,rsa.getPublicExponent().intValue());
        return nul(Base64.encodeToString(buf,Base64.NO_WRAP)+" freedom-picture@localhost");
    }
    private static byte[] adbSignature(PrivateKey privateKey,byte[] token)throws Exception{
        if(token.length!=20)throw new java.io.IOException("Unexpected ADB AUTH token length");
        byte[] digestInfo=new byte[SHA1_DIGEST_INFO.length+token.length];
        System.arraycopy(SHA1_DIGEST_INFO,0,digestInfo,0,SHA1_DIGEST_INFO.length);
        System.arraycopy(token,0,digestInfo,SHA1_DIGEST_INFO.length,token.length);
        Cipher c=Cipher.getInstance("RSA/ECB/PKCS1Padding");c.init(Cipher.ENCRYPT_MODE,privateKey);
        return c.doFinal(digestInfo);
    }
    /** Synchronous: invoke on a worker thread. User must approve the receiver's RSA trust prompt. */
    public static String connectAndCheck(Context context){
        StringBuilder result=new StringBuilder("Receiver local ADB: 127.0.0.1:5556\n");
        result.append("Permission scope: ADB shell after explicit device authorization, NOT root.\n\n");
        boolean pubSent=false, signatureSent=false,connected=false;
        try(Socket socket=new Socket()){
            socket.connect(new InetSocketAddress(HOST,PORT),3000);
            socket.setSoTimeout(2500);
            InputStream in=socket.getInputStream();OutputStream out=socket.getOutputStream();
            send(out,CNXN,0x01000000,4096,nul("host::"));
            KeyPair pair=null;
            long deadline=SystemClock.elapsedRealtime()+35000;
            while(SystemClock.elapsedRealtime()<deadline&&!connected){
                Packet p;
                try{p=receive(in);}catch(java.net.SocketTimeoutException e){continue;}
                if(p.command==CNXN){connected=true;break;}
                if(p.command!=AUTH || p.arg0!=AUTH_TOKEN)
                    throw new java.io.IOException("Expected ADB AUTH/CNXN, received "+Integer.toHexString(p.command));
                if(pair==null)pair=keyPair(context);
                if(!signatureSent){
                    send(out,AUTH,AUTH_SIGNATURE,0,adbSignature(pair.getPrivate(),p.data));signatureSent=true;
                } else if(!pubSent){
                    send(out,AUTH,AUTH_RSAPUBLICKEY,0,adbPublicKey((RSAPublicKey)pair.getPublic()));pubSent=true;
                }
                // Once the public key is sent the receiver may show an RSA authorization prompt.
            }
            if(!connected){
                if(pubSent)result.append("AUTHORIZATION PENDING: approve 'Allow USB debugging?' on this receiver, then retry.\n");
                else result.append("ADB handshake timed out. Check wireless ADB port and authentication.\n");
                return result.toString();
            }
            result.insert(0,"AUTHORIZED • ADB transport connected\n");
            send(out,OPEN,1,0,nul("shell:id"));
            long shellDeadline=SystemClock.elapsedRealtime()+8000;
            int remoteId=0;
            StringBuilder shell=new StringBuilder();
            boolean shellOpened=false;
            while(SystemClock.elapsedRealtime()<shellDeadline){
                Packet p;
                try{p=receive(in);}catch(java.net.SocketTimeoutException e){continue;}
                if(p.command==OKAY && p.arg1==1){shellOpened=true;remoteId=p.arg0;}
                else if(p.command==WRTE && p.arg1==1){
                    if(remoteId==0)remoteId=p.arg0;
                    shell.append(new String(p.data,StandardCharsets.UTF_8));
                    send(out,OKAY,1,remoteId,new byte[0]);
                } else if(p.command==CLSE && p.arg1==1){
                    if(remoteId==0)remoteId=p.arg0;
                    send(out,CLSE,1,remoteId,new byte[0]);break;
                }
            }
            if(shell.length()>0){
                result.append("Read-only shell id result:\n").append(shell.toString().trim()).append("\n");
            }else if(shellOpened){result.append("ADB shell opened; 'id' response not received within timeout.\n");}
            else result.append("ADB transport authorized; opening shell did not succeed.\n");
            result.append("No PQ settings changed; no root or hidden system APIs used.\n");
        }catch(java.net.ConnectException e){
            result.append("CONNECTION REFUSED: adbd is not listening at localhost:5556 on the receiver.\n");
        }catch(Exception e){result.append("FAILED: ").append(e.getClass().getSimpleName())
                .append(": ").append(String.valueOf(e.getMessage())).append("\n");}
        return result.toString();
    }
}
