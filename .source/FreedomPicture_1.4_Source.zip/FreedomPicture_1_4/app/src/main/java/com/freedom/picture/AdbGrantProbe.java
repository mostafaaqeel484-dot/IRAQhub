package com.freedom.picture;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Process;
import java.util.Arrays;

/** Read-only permission inspection. No root, shell or adb server in this app. */
public final class AdbGrantProbe {
    private static final String[] PERMISSIONS={
        "android.permission.WRITE_SECURE_SETTINGS",
        "android.permission.DUMP",
        "android.permission.READ_LOGS"
    };
    private AdbGrantProbe(){}

    public static String report(Context context){
        StringBuilder out=new StringBuilder();
        String pkg=context.getPackageName();
        PackageManager pm=context.getPackageManager();
        String[] requested={};
        try{
            PackageInfo info=pm.getPackageInfo(pkg,PackageManager.GET_PERMISSIONS);
            if(info.requestedPermissions!=null)requested=info.requestedPermissions;
        } catch(Exception err){out.append("Package manifest check failed: ").append(err).append("\n");}
        out.append("Freedom Picture 1.3 • ADB development permission probe\n");
        out.append("Device: ").append(Build.HARDWARE).append(" / Android ").append(Build.VERSION.RELEASE)
           .append(" | app UID: ").append(Process.myUid()).append("\n\n");
        for(String p:PERMISSIONS){
            boolean declared=Arrays.asList(requested).contains(p);
            boolean granted=pm.checkPermission(p,pkg)==PackageManager.PERMISSION_GRANTED;
            out.append(p).append("\n  declared: ").append(declared)
                .append(" | granted: ").append(granted).append("\n");
        }
        out.append("\nRun on your phone's Termux (ADB device already paired):\n");
        for(String p:PERMISSIONS){
            out.append("adb -s 192.168.0.214:5556 shell pm grant ")
                .append(pkg).append(" ").append(p).append("\n");
        }
        out.append("\nReopen this check afterwards. A grant may be refused by your ROM.\n");
        out.append("NOTE: These are development permissions, NOT ADB shell (uid 2000), ")
           .append("NOT root (uid 0), NOT a sysfs/PQ write grant.\n");
        out.append("No system settings, service transactions or video parameters are changed by this check.");
        return out.toString();
    }
}
