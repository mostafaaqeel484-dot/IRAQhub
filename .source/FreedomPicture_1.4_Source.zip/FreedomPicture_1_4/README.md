# Freedom Picture 1.4 — ADB loopback test

Adds a user-triggered **ADB CONNECT 127.0.0.1:5556** button to the existing 1.3 app.
This is a minimal in-process ADB TCP client: creates an app-private RSA key,
performs the ADB transport handshake, requests user authorization when the local
ADB daemon requires it, and opens a read-only `shell:id` stream to prove
successful authorization.

- The address refers to the **receiver itself** because Freedom Picture runs on the receiver. It does not refer to the phone running Termux.
- `INTERNET` permission is added for local TCP sockets. No remote server or subscription.
- Key is held in app-private `getNoBackupFilesDir()` and is not uploaded or exposed in logs.
- The receiver may show a "Allow USB debugging?" authorization prompt. Approve only if you trust the app and you are operating your own receiver.
- Success means a local ADB shell session, **not root** (`uid=2000(shell)` on the tested receiver) and does not grant PQ control, HIDL privilege, or sysfs write permission.
- The button **only runs the read-only command `id`**. It cannot apply image profiles and does not attempt to alter any image-control files.
- If adbd is bound only to the TV's LAN address and not loopback, `127.0.0.1:5556` may refuse the connection even when `192.168.0.214:5556` works remotely.
- Existing ADB-grantable permissions (`WRITE_SECURE_SETTINGS`, `DUMP`, `READ_LOGS`) remain intact; a package upgrade normally retains their grants if the package signature is unchanged.

Build using Gradle, JDK 17, and the Android SDK:

```
gradle --no-daemon assembleDebug
```

Package: `com.freedom.picture` / version `1.4.0-local-adb` (code 5). Full original-app license checks are neither copied nor bypassed.
